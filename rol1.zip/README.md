### ❗ Requisito previo: instalar CMake en tu sistema

- **macOS**: `brew install cmake`
- **Linux**: `sudo apt install cmake`
- **Windows**: Descarga desde https://cmake.org/download/ y agrégalo al PATH
